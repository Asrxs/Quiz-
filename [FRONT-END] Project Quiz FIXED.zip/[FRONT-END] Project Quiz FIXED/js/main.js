const app = document.getElementById('js--id');

let playerName = '';
let gebruikersAntwoorden = [];
let huidigeVraagIndex = 0;
let quizVragen = [];
let timer;
const tijdPerVraag = 16;

function welkomstPagina() {
    renderWelkomstPagina();
    const startKnop = document.getElementById('js--button');
    const naamInput = document.getElementById('js--input');

    startKnop.addEventListener('click', startQuiz);
    naamInput.addEventListener('keydown', function (event) {
        if (event.keyCode === 13) {
            startQuiz();
        }
    });
}

function renderWelkomstPagina() {
    app.innerHTML = `
                    <article class="container">
                        <header class="header">
                            <h1 class="title">Welkom!</h1>
                        </header>
                        <div class="space"></div>
                        <div class="explanation">
                            <p class="explain">
                                Welkom op mijn quizwebsite! Voer eerst je naam in op de startpagina. 
                                Vervolgens kun je kiezen uit drie boeiende categorieën: topografie, 
                                rekenen of natuurkunde. Elke quiz bestaat uit 15 zorgvuldig samengestelde vragen. 
                                Voor elke vraag heb je 12 seconden om te antwoorden, 
                                wat het spel spannend houdt en zowel je kennis als je reactievermogen test.

                                Aan het einde van de quiz krijg je een overzicht van je prestaties, 
                                inclusief de juiste antwoorden en je totale score. 
                                Zorg ervoor dat je in een rustige omgeving bent zodat je je kunt concentreren, 
                                lees elke vraag zorgvuldig, en probeer snel te antwoorden. Veel plezier en succes! Heb je nog vragen of suggesties? Neem gerust contact met ons op via de contactpagina.
                            </p>
                        </div>
                        <div class="interaction">
                            <p class="question">Wat is je naam?</p>
                        </div>
                        <div class="container-input">
                            <input id="js--input" class="input" type="text" placeholder="Naam...">
                        </div>
                        <div class="container-button">
                            <button id="js--button" class="button" type="button">Start quiz</button>
                        </div>
                    </article>
                `;
}

function startQuiz() {
    const naamInputValue = document.getElementById('js--input').value.trim();
    if (naamInputValue.length > 0) {
        playerName = naamInputValue;
        renderQuizPagina();
    } else {
        alert("Vul je naam in");
    }
}

function renderQuizPagina() {
    app.innerHTML = `
                    <a id="js--previous" href="#" class="previous">&laquo; Teruggaan</a>
                    <div class="container-title">
                        <h1>Welkom, ${playerName}! Welke onderwerp?</h1>
                    </div>
                    <article class="container-images">
                        <div id="js--rekenen" class="container-image">
                            <img class="image" src="/images/calculator.png" alt="">
                        </div>
                        <div id="js--topografie" class="container-image">
                            <img class="image" src="/images/world.png" alt="">
                        </div>
                        <div id="js--natuurkunde" class="container-image">
                            <img class="image" src="/images/relativity.png" alt="">
                        </div>
                    </article>
                `;

    document.getElementById('js--previous').addEventListener('click', function (event) {
        event.preventDefault();
        welkomstPagina();
    });

    document.getElementById('js--rekenen').addEventListener('click', function () {
        laadQuiz('Rekenen');
    });

    document.getElementById('js--topografie').addEventListener('click', function () {
        laadQuiz('Topografie');
    });

    document.getElementById('js--natuurkunde').addEventListener('click', function () {
        laadQuiz('Natuurkunde');
    });
}

async function laadQuiz(categorie) {
    try {
        const response = await fetch('/vragenlijst/quizdata.json');
        const data = await response.json();
        quizVragen = data[categorie];

        if (!quizVragen) {
            console.error(`Geen quizvragen gevonden voor categorie: ${categorie}`);
            return;
        }

        quizVragen = shuffleArray(quizVragen);

        huidigeVraagIndex = 0;
        gebruikersAntwoorden = [];
        startQuizVragen();
    } catch (error) {
        console.error('Fout bij het laden van de quizgegevens:', error);
    }
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function startQuizVragen() {
    function renderVraag() {
        const vraag = quizVragen[huidigeVraagIndex];
        if (!vraag) {
            toonResultaten();
            return;
        }

        const opties = vraag.opties;
        const half = Math.ceil(opties.length / 2);

        const eersteHelft = opties.slice(0, half).map(optie => `<button class="button">${optie}</button>`).join('');
        const tweedeHelft = opties.slice(half).map(optie => `<button class="button">${optie}</button>`).join('');

        app.innerHTML = `
            <div class="unique-container-title">
                <h1 class="unique-title">${vraag.vraag}</h1>
            </div>
            <div class="unique-container-image">
                <p class="unique-team-text">${playerName}</p>
                <img class="unique-images" src="${vraag.image}" alt="" />
                <div class="unique-timer">
                    <p id="timer" class="unique-timer-text">${tijdPerVraag}</p> <!-- Zet de ID voor het timer element -->
                </div>
            </div>
            <div class="unique-container-buttons">
                ${eersteHelft}
            </div>
            <div class="unique-container-buttons">
                ${tweedeHelft}
            </div>
        `;

        let tijdOver = tijdPerVraag;
        const timerElement = document.getElementById('timer');

        let timer = setInterval(() => {
            tijdOver--;
            timerElement.textContent = tijdOver;
            if (tijdOver <= 0) {
                clearInterval(timer);
                gebruikersAntwoorden.push({
                    vraag: vraag.vraag,
                    gegevenAntwoord: 'Geen antwoord',
                    correctAntwoord: vraag.antwoord
                });

                huidigeVraagIndex++;
                renderVraag();
            }
        }, 1000);

        document.querySelectorAll('.button').forEach(button => {
            button.addEventListener('click', function () {
                const geselecteerdeAntwoord = this.textContent;
                clearInterval(timer);
                gebruikersAntwoorden.push({
                    vraag: vraag.vraag,
                    gegevenAntwoord: geselecteerdeAntwoord,
                    correctAntwoord: vraag.antwoord
                });

                huidigeVraagIndex++;
                renderVraag();
            });
        });
    }

    renderVraag();
}

function toonResultaten() {
    let correcteAntwoorden = 0;
    let resultatenHTML = '';

    gebruikersAntwoorden.forEach((antwoord, index) => {
        const isCorrect = antwoord.gegevenAntwoord === antwoord.correctAntwoord;
        if (isCorrect) {
            correcteAntwoorden++;
        }

        resultatenHTML += `
                        <div class="resultaat-vraag">
                            <h2>Vraag ${index + 1}: ${antwoord.vraag}</h2>
                            <p>Je antwoord: ${antwoord.gegevenAntwoord} ${isCorrect ? '✅' : '❌'}</p>
                            ${!isCorrect ? `<p>Correct antwoord: ${antwoord.correctAntwoord}</p>` : ''}
                        </div>
                    `;
    });

    app.innerHTML = `
                    <div class="quiz-resultaten">
                        <h1>Resultaten van ${playerName}</h1>
                        <p>Je hebt ${correcteAntwoorden} van de ${gebruikersAntwoorden.length} vragen goed!</p>
                    </div>
                    ${resultatenHTML}
                    <button id="js--opnieuw" class="button">Opnieuw spelen</button>
                `;

    document.getElementById('js--opnieuw').addEventListener('click', function () {
        welkomstPagina();
    });
}
welkomstPagina();